package mainAtm;

import java.io.IOException;

import atm.OptionMenu;

public class ATM extends OptionMenu {
public static void main(String[] args)throws IOException {
		OptionMenu optionMenu = new OptionMenu();
		optionMenu.getLogin();
		
		}

}